import assert from "node:assert/strict";
import { chromium } from "playwright";
import { writeFile } from "node:fs/promises";
const base = process.env.LAB_URL ?? "http://127.0.0.1:4488";
const results = [];
const browser = await chromium.launch({ headless: true });
async function check(name, fn) {
  const p = await browser.newPage();
  p.setDefaultTimeout(10000);
  p.setDefaultNavigationTimeout(20000);
  const errors = [];
  p.on("pageerror", (e) => errors.push(e.message));
  try {
    const observed = await fn(p);
    assert.deepEqual(errors, []);
    results.push({ name, pass: true, observed, errors });
  } catch (e) {
    results.push({ name, pass: false, error: e.message, errors });
  } finally {
    console.log(`${results.at(-1).pass ? "PASS" : "FAIL"} ${name}`);
    await p.close();
  }
}
await check("2000-rows-50-reorders-and-unsaved-local-state", async (p) => {
  await p.goto(base + "/?count=2000");
  assert.equal(await p.locator("#incidents tr").count(), 2000);
  const ids = [1, 73, 450, 1989];
  for (const id of ids) await p.locator(`[data-row="${id}"] input`).fill(`draft-${id}`);
  await p.locator('[data-row="1"] input').evaluate((e) => (globalThis.__node = e));
  for (let i = 0; i < 50; i++) {
    await p.locator("#reverse").click();
    const first = i % 2 === 0 ? "2000" : "1";
    await p.waitForFunction((id) => document.querySelector("#incidents tr")?.getAttribute("data-row") === id, first);
  }
  for (const id of ids) assert.equal(await p.locator(`[data-row="${id}"] input`).inputValue(), `draft-${id}`);
  assert.ok(await p.locator('[data-row="1"] input').evaluate((e) => e === globalThis.__node));
  return { rows: 2000, reorders: 50, drafts: ids.length, nodeIdentity: true };
});
await check("20-transport-mount-unmount-cycles", async (p) => {
  await p.goto(base);
  const before = await (await fetch(base + "/api/stats")).json();
  for (let i = 0; i < 20; i++) {
    await p.locator("#connect").click();
    await p.waitForFunction(
      () => Number(document.querySelector("#sse-count")?.textContent) >= 2 && Number(document.querySelector("#ws-count")?.textContent) >= 2,
    );
    await p.locator("#connect").click();
    await p.locator("#sse-count").waitFor({ state: "detached" });
  }
  await p.waitForTimeout(150);
  const after = await (await fetch(base + "/api/stats")).json();
  assert.equal(after.sseActive, 0);
  assert.equal(after.wsActive, 0);
  assert.equal(after.sseStarted - before.sseStarted, 20);
  assert.equal(after.wsStarted - before.wsStarted, 20);
  return { cycles: 20, before, after };
});
await check("cold-input-with-delayed-javascript-chunks", async (p) => {
  await p.route("**/assets/*.js", async (route) => {
    await new Promise((r) => setTimeout(r, 200));
    await route.continue();
  });
  await p.goto(base, { waitUntil: "domcontentloaded" });
  await p.locator("#editor-text").fill("typed before code arrived");
  await p.locator("#severity").selectOption("critical");
  await p.waitForFunction(() => document.querySelector("#editor-output")?.textContent === "critical:typed before code arrived");
  return { keptUserInput: true, chunkDelayMs: 200 };
});
await check("20-resource-supersession-rounds", async (p) => {
  await p.goto(base);
  for (let i = 0; i < 20; i++) {
    const completed = p.waitForResponse((r) => new URL(r.url()).pathname === "/api/search" && new URL(r.url()).searchParams.get("q") === "fast");
    await p.locator("#slow-search").click();
    await p.locator("#fast-search").click();
    const response = await completed;
    assert.equal(response.status(), 200);
    await response.finished();
    await p.waitForFunction(() => document.querySelector("#search-state")?.textContent === "ready");
    await p.waitForFunction(() => document.querySelector("#search-result")?.textContent === "fast");
  }
  await p.waitForTimeout(350);
  assert.equal(await p.locator("#search-result").textContent(), "fast");
  return { rounds: 20, last: "fast" };
});
await browser.close();
await writeFile(new URL("../results/stress.json", import.meta.url), JSON.stringify(results, null, 2));
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
