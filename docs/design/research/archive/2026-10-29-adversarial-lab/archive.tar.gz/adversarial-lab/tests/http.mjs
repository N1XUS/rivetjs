import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
const base = process.env.LAB_URL ?? "http://127.0.0.1:4488";
const results = [];
async function check(name, fn) {
  try {
    results.push({ name, pass: true, observed: await fn() });
  } catch (e) {
    results.push({ name, pass: false, error: e.message, actual: e.actual, expected: e.expected });
  }
}
await check("ssr-dashboard-is-real-html", async () => {
  const r = await fetch(base);
  const text = await r.text();
  assert.equal(r.status, 200);
  assert.match(text, /Incident operations/);
  assert.match(text, /Incident 001/);
  return { status: r.status, bytes: Buffer.byteLength(text) };
});
await check("ssr-request-isolation-40-concurrent-users", async () => {
  const names = Array.from({ length: 40 }, (_, i) => `USER_${String(i).padStart(3, "0")}_END`);
  const pages = await Promise.all(names.map(async (u) => (await fetch(`${base}/identity?user=${u}`)).text()));
  for (let i = 0; i < pages.length; i++) {
    assert.ok(pages[i].includes(names[i]));
    for (let j = 0; j < names.length; j++) if (i !== j) assert.ok(!pages[i].includes(names[j]), `${names[j]} leaked to ${names[i]}`);
  }
  return { users: 40 };
});
await check("ssr-escapes-attacker-text", async () => {
  const attack = '<img src=x onerror="globalThis.pwned=1">';
  const text = await (await fetch(`${base}/identity?user=${encodeURIComponent(attack)}`)).text();
  assert.ok(!text.includes(attack));
  assert.match(text, /&lt;img/);
  return { escaped: true };
});
await check("protected-loader-denies-anonymous", async () => {
  const r = await fetch(`${base}/private`, { redirect: "manual" });
  assert.equal(r.status, 403);
  return { status: r.status };
});
await check("enclosing-guard-protects-response-handler", async () => {
  const r = await fetch(`${base}/private/export`, { redirect: "manual" });
  const body = await r.text();
  assert.equal(r.status, 403, `anonymous received ${r.status}: ${body}`);
  return { status: r.status };
});
await check("enclosing-guard-protects-page-response-handler", async () => {
  const r = await fetch(`${base}/private/report`, { redirect: "manual" });
  const body = await r.text();
  assert.equal(r.status, 403, `anonymous received ${r.status}: ${body}`);
  return { status: r.status };
});
await check("live-page-SSR-data-contract", async () => {
  const r = await fetch(`${base}/live`);
  const body = await r.text();
  assert.equal(r.status, 200, body);
  assert.match(body, /id="live-draft"/);
  return { status: r.status };
});
await check("deferred-SSR-shell-then-content", async () => {
  const response = await fetch(`${base}/stream`);
  assert.equal(response.status, 200);
  const reader = response.body.getReader();
  const chunks = [];
  const decoder = new TextDecoder();
  let next;
  while (!(next = await reader.read()).done) chunks.push(decoder.decode(next.value, { stream: true }));
  const all = chunks.join("");
  assert.match(all, /Stream shell/);
  assert.match(all, /deferred-payload/);
  assert.ok(chunks.length >= 2, "deferred output must arrive in more than one body chunk");
  let accumulated = "",
    shellChunk = -1,
    payloadChunk = -1;
  for (let i = 0; i < chunks.length; i++) {
    accumulated += chunks[i];
    if (shellChunk < 0 && accumulated.includes("Stream shell")) shellChunk = i;
    if (payloadChunk < 0 && accumulated.includes("deferred-payload")) payloadChunk = i;
  }
  assert.ok(
    shellChunk >= 0 && payloadChunk > shellChunk,
    "shell must be observable in the stream before the deferred payload (a head-only first chunk is valid)",
  );
  return { chunks: chunks.length, shellChunk, payloadChunk };
});
await check("cross-origin-post-rejected", async () => {
  const r = await fetch(`${base}/api/tasks`, {
    method: "POST",
    headers: { origin: "https://attacker.invalid", "content-type": "application/json" },
    body: '{"title":"pwn"}',
  });
  assert.equal(r.status, 403);
  return { status: r.status };
});
await check("same-origin-ajax-cas-conflict", async () => {
  const token = `http-${Date.now()}`;
  const post = (version) =>
    fetch(`${base}/api/tasks?token=${token}`, {
      method: "POST",
      headers: { origin: base, "content-type": "application/json" },
      body: JSON.stringify({ version, title: "edited" }),
    });
  assert.equal((await post(0)).status, 200);
  assert.equal((await post(0)).status, 409);
  return { conflict: 409 };
});
await check("sse-delivers-in-order", async () => {
  const text = await (await fetch(`${base}/api/events?limit=8&ms=5`)).text();
  const ids = [...text.matchAll(/^id: (\d+)/gm)].map((m) => Number(m[1]));
  assert.deepEqual(ids, [1, 2, 3, 4, 5, 6, 7, 8]);
  return { ids };
});
await check("sse-disconnect-disposes-producer", async () => {
  const controller = new AbortController();
  const r = await fetch(`${base}/api/events?limit=10000&ms=10`, { signal: controller.signal });
  const reader = r.body.getReader();
  await reader.read();
  controller.abort();
  await new Promise((r) => setTimeout(r, 200));
  const stats = await (await fetch(`${base}/api/stats`)).json();
  assert.equal(stats.sseActive, 0);
  return stats;
});
await check("progressive-form-without-javascript", async () => {
  const r = await fetch(`${base}/?/add`, {
    method: "POST",
    redirect: "manual",
    headers: { origin: base, "content-type": "application/x-www-form-urlencoded" },
    body: "title=from-native-form",
  });
  assert.equal(r.status, 303);
  assert.equal(r.headers.get("location"), "/");
  return { status: r.status };
});
await mkdir(new URL("../results/", import.meta.url), { recursive: true });
await writeFile(new URL("../results/http.json", import.meta.url), JSON.stringify(results, null, 2));
for (const r of results) console.log(`${r.pass ? "PASS" : "FAIL"} ${r.name}${r.pass ? "" : `: ${r.error}`}`);
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
