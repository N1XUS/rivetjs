import assert from "node:assert/strict";
import { chromium } from "playwright";
import { writeFile } from "node:fs/promises";
import { createRoot, createSignal, createResource } from "../../apps/bench-stable/node_modules/solid-js/dist/solid.js";
const base = process.env.NEXT_URL ?? "http://127.0.0.1:4489";
const results = [];
async function check(name, framework, fn) {
  try {
    results.push({ name, framework, pass: true, observed: await fn() });
  } catch (e) {
    results.push({ name, framework, pass: false, error: e.message });
  }
  console.log(`${results.at(-1).pass ? "PASS" : "FAIL"} ${framework} ${name}`);
}
const browser = await chromium.launch({ headless: true });
async function withPage(path, fn) {
  const p = await browser.newPage();
  p.setDefaultTimeout(6000);
  try {
    const r = await p.goto(base + path);
    assert.equal(r.status(), 200);
    return await fn(p);
  } finally {
    await p.close();
  }
}
await check("live-navigation-preserves-draft-and-refreshes-rows", "next-16/react-19", () =>
  withPage("/", async (p) => {
    await p.locator("#live-draft").fill("keep me");
    await p.locator("#live-next").click();
    await p.waitForFunction(() => document.querySelector("#live-page")?.textContent === "2");
    assert.equal(await p.locator("#live-draft").inputValue(), "keep me");
    return { SSR: 200, page: 2, draft: "keep me" };
  }),
);
await check("read-then-truncate-removes-elements", "react-19-immutable-updater", () =>
  withPage("/state", async (p) => {
    await p.locator("#produce-truncate").click();
    await p.waitForFunction(() => document.querySelector("#produce-length")?.textContent === "0");
    assert.equal(await p.locator("#produce-second").textContent(), "absent");
    return { length: 0, second: "absent" };
  }),
);
await check("reactive-async-updates-on-source-change", "react-19-useEffect", () =>
  withPage("/async", async (p) => {
    await p.locator("#async-next").click();
    await p.waitForFunction(() => document.querySelector("#async-result")?.textContent === "2");
    return { source: 2, value: 2 };
  }),
);
await check("resource-reacts-to-source-change", "solid-1.9", async () => {
  let dispose, setPage, value;
  createRoot((d) => {
    dispose = d;
    const [p, set] = createSignal(1);
    setPage = set;
    [value] = createResource(p, async (n) => {
      await new Promise((r) => setTimeout(r, 10));
      return n;
    });
  });
  try {
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(value(), 1);
    setPage(2);
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(value(), 2);
    return { source: 2, value: 2 };
  } finally {
    dispose();
  }
});
await browser.close();
await writeFile(new URL("../results/controls.json", import.meta.url), JSON.stringify(results, null, 2));
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
