import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import { createStore, read, write, produce, reconcile } from "@rivetjs/reactivity/store";
import { createRoot, effect, signal, computed, batch } from "@rivetjs/reactivity";
import {
  createStore as solidStore,
  produce as solidProduce,
  reconcile as solidReconcile,
} from "../../apps/bench-stable/node_modules/solid-js/store/dist/store.js";
import { createRoot as solidRoot, createComputed } from "../../apps/bench-stable/node_modules/solid-js/dist/solid.js";

const results = [];
function check(name, framework, fn) {
  try {
    const observed = fn();
    results.push({ name, framework, pass: true, observed });
  } catch (e) {
    results.push({ name, framework, pass: false, error: e.message, actual: e.actual, expected: e.expected, observed: e.observed });
  }
}
const cases = [
  {
    name: "array-index-extension-updates-length",
    initial: { items: [{ n: 1 }] },
    path: "items.length",
    expected: 4,
    rivet: (s) => write(s, "items.3", { n: 4 }),
    solid: (set) => set("items", 3, { n: 4 }),
  },
  {
    name: "array-length-truncation-invalidates-index",
    initial: { items: [{ n: 1 }, { n: 2 }] },
    path: "items.1.n",
    expected: undefined,
    rivet: (s) => write(s, "items.length", 1),
    solid: (set) => set("items", "length", 1),
  },
  {
    name: "array-truncate-draft-does-not-resurrect-read-child",
    initial: { items: [{ n: 1 }, { n: 2 }] },
    path: "items.length",
    expected: 0,
    rivet: (s) =>
      write(
        s,
        produce((d) => {
          void d.items[1].n;
          d.items.length = 0;
        }),
      ),
    solid: (set) =>
      set(
        solidProduce((d) => {
          void d.items[1].n;
          d.items.length = 0;
        }),
      ),
  },
  {
    name: "reconcile-preserves-trailing-array-holes-length",
    initial: { items: [1] },
    path: "items.length",
    expected: 4,
    rivet: (s) => {
      const a = [1];
      a.length = 4;
      write(s, reconcile({ items: a }));
    },
    solid: (set) => {
      const a = [1];
      a.length = 4;
      set(solidReconcile({ items: a }));
    },
  },
  {
    name: "nested-path-invalidation-positive-control",
    initial: { items: [{ n: 1 }, { n: 2 }] },
    path: "items.1.n",
    expected: 99,
    rivet: (s) => write(s, "items.1.n", 99),
    solid: (set) => set("items", 1, "n", 99),
  },
];
for (const c of cases) {
  check(c.name, "rivet", () =>
    createRoot((dispose) => {
      try {
        const s = createStore(structuredClone(c.initial));
        let seen;
        effect(() => {
          seen = read(s, c.path);
        });
        c.rivet(s);
        const whole = read(s);
        const actual = { observed: seen, pathRead: read(s, c.path), whole: JSON.stringify(whole) };
        try {
          assert.equal(seen, c.expected);
          assert.equal(read(s, c.path), c.expected);
        } catch (e) {
          e.observed = actual;
          throw e;
        }
        return actual;
      } finally {
        dispose();
      }
    }),
  );
  check(c.name, "solid-1.9", () =>
    solidRoot((dispose) => {
      try {
        const [s, set] = solidStore(structuredClone(c.initial));
        let seen;
        const get = () => c.path.split(".").reduce((v, k) => v?.[k], s);
        createComputed(() => {
          seen = get();
        });
        c.solid(set);
        assert.equal(seen, c.expected);
        assert.equal(get(), c.expected);
        return { observed: seen, whole: JSON.stringify(s) };
      } finally {
        dispose();
      }
    }),
  );
}
check("batched-diamond-is-consistent", "rivet", () =>
  createRoot((dispose) => {
    try {
      const n = signal(1),
        a = computed(() => n() * 2),
        b = computed(() => n() * 3);
      const seen = [];
      effect(() => seen.push([n(), a(), b()]));
      batch(() => {
        n.set(2);
        n.set(3);
      });
      assert.deepEqual(seen, [
        [1, 2, 3],
        [3, 6, 9],
      ]);
      return seen;
    } finally {
      dispose();
    }
  }),
);
await mkdir(new URL("../results/", import.meta.url), { recursive: true });
await writeFile(new URL("../results/state.json", import.meta.url), JSON.stringify(results, null, 2));
for (const r of results) console.log(`${r.pass ? "PASS" : "FAIL"} ${r.framework} ${r.name}${r.pass ? "" : `: ${r.error}`}`);
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
