import assert from "node:assert/strict";
import { chromium } from "playwright";
import { writeFile, mkdir } from "node:fs/promises";
const base = process.env.LAB_URL ?? "http://127.0.0.1:4488";
const browser = await chromium.launch({ headless: true });
const results = [];
await mkdir(new URL("../results/sites/", import.meta.url), { recursive: true });
async function login(context, email = "alice@alpha.test") {
  const r = await context.request.post(base + "/auth/session", { headers: { origin: base }, data: { email, password: "demo-pass-2026" } });
  assert.equal(r.status(), 200);
}
async function api(context, path, method = "GET", data) {
  const r = await context.request.fetch(base + path, { method, headers: { origin: base }, ...(data === undefined ? {} : { data }) });
  return { status: r.status(), data: await r.json() };
}
async function clearCart(context) {
  let c = (await api(context, "/store/api/cart")).data;
  for (const item of c.items) {
    const r = await api(context, "/store/api/cart", "PUT", { version: c.version, sku: item.product.sku, quantity: 0 });
    assert.equal(r.status, 200);
    c = r.data;
  }
}
async function add(context, sku = "sku-1", quantity = 1) {
  const c = (await api(context, "/store/api/cart")).data;
  const r = await api(context, "/store/api/cart", "PUT", { version: c.version, sku, quantity });
  assert.equal(r.status, 200);
  return r.data;
}
async function check(name, fn, options = {}) {
  const context = await browser.newContext(options);
  context.setDefaultTimeout(8000);
  context.setDefaultNavigationTimeout(15000);
  const errors = [];
  context.on("page", (p) => p.on("pageerror", (e) => errors.push(e.message)));
  const page = await context.newPage();
  const started = Date.now();
  try {
    const observed = await fn(page, context);
    assert.deepEqual(errors, []);
    results.push({ name, pass: true, observed, errors, elapsedMs: Date.now() - started });
  } catch (e) {
    await page.screenshot({ path: new URL(`../results/sites/${name}.png`, import.meta.url).pathname, fullPage: false }).catch(() => {});
    results.push({
      name,
      pass: false,
      error: e.message,
      errors,
      url: page.url(),
      body: (
        await page
          .locator("body")
          .innerText()
          .catch(() => "")
      ).slice(0, 3500),
      elapsedMs: Date.now() - started,
    });
  } finally {
    console.log(`${results.at(-1).pass ? "PASS" : "FAIL"} ${name}`);
    await context.close();
  }
}
await check("storefront-server-html-and-24-products", async (p) => {
  const r = await p.goto(base + "/store");
  assert.equal(r.status(), 200);
  assert.equal(await p.locator("[data-product]").count(), 24);
  await p.screenshot({ path: new URL("../results/sites/storefront.png", import.meta.url).pathname, fullPage: false });
  return { products: 24 };
});
await check("catalog-query-sort-reload-back-forward", async (p) => {
  await p.goto(base + "/store");
  await p.locator("#shop-search").fill("notebook");
  await p.locator("#shop-sort").selectOption("price");
  await p.locator("#shop-filter").click();
  await p.waitForURL(/q=notebook/);
  assert.equal(await p.locator("[data-product]").count(), 3);
  await p.reload();
  assert.equal(await p.locator("#shop-search").inputValue(), "notebook");
  await p.goto(base + "/store?category=Wear");
  assert.equal(await p.locator("[data-product]").count(), 8);
  await p.goBack();
  assert.equal(await p.locator("#shop-search").inputValue(), "notebook");
  await p.goForward();
  assert.equal(await p.locator("#shop-category").inputValue(), "Wear");
  return { search: 3, category: 8, history: true };
});
await check(
  "catalog-native-filter-without-javascript",
  async (p) => {
    await p.goto(base + "/store");
    await p.locator("#shop-search").fill("lamp");
    await p.locator("#shop-filter").click();
    await p.waitForURL(/q=lamp/);
    assert.equal(await p.locator("[data-product]").count(), 3);
    return { products: 3 };
  },
  { javaScriptEnabled: false },
);
await check("product-deep-link-and-real-404", async (p) => {
  await p.goto(base + "/store/products/sku-1");
  assert.match(await p.locator("h1").innerText(), /Canvas/);
  assert.match(await p.locator("#stock").innerText(), /in stock/);
  assert.equal((await p.goto(base + "/store/products/missing")).status(), 404);
  return { deepLink: 200, missing: 404 };
});
await check(
  "mobile-storefront-does-not-overflow",
  async (p) => {
    await p.goto(base + "/store");
    assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    return { width: 375 };
  },
  { viewport: { width: 375, height: 812 } },
);
await check(
  "native-sign-in-without-javascript",
  async (p) => {
    await p.goto(base + "/sign-in");
    await p.locator("#login-email").fill("editor@alpha.test");
    await p.locator("#login-password").fill("demo-pass-2026");
    await p.locator("#login-submit").click();
    await p.waitForURL(base + "/desk");
    assert.match(await p.locator("#desk-identity").innerText(), /Jules Editor/);
    return { signedIn: true };
  },
  { javaScriptEnabled: false },
);
await check("wrong-password-shows-error-and-no-session", async (p, c) => {
  await p.goto(base + "/sign-in");
  await p.locator("#login-email").fill("alice@alpha.test");
  await p.locator("#login-password").fill("wrong-secret");
  await p.locator("#login-submit").click();
  await p.locator('[role="alert"]').waitFor();
  assert.ok(!(await c.cookies()).some((x) => x.name === "case-session"));
  assert.ok(!(await p.content()).includes("wrong-secret"));
  return { session: false };
});
await check("httpOnly-session-is-not-readable-by-javascript", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk");
  assert.ok(!(await p.evaluate(() => document.cookie)).includes("case-session"));
  return { httpOnly: true };
});
await check("cart-add-quantity-promotion-and-reload", async (p, c) => {
  await login(c);
  await clearCart(c);
  await p.goto(base + "/store");
  const added = p.waitForResponse((r) => r.url().endsWith("/store/api/cart") && r.request().method() === "PUT");
  await p.locator('[data-product="sku-1"] .add-to-cart').click();
  assert.equal((await added).status(), 200);
  await p.goto(base + "/store/cart");
  await p.locator('[data-cart-sku="sku-1"] .increase').click();
  await p.waitForFunction(() => document.querySelector(".quantity")?.textContent === "2");
  await p.locator("#coupon").fill("DEMO10");
  const promoted = p.waitForResponse((r) => r.url().endsWith("/store/api/cart") && r.request().method() === "PUT");
  await p.locator("#apply-coupon").click();
  await promoted;
  await p.waitForFunction(() => document.querySelector("#discount")?.textContent !== "$0.00");
  const total = await p.locator("#cart-total").innerText();
  await p.reload();
  assert.equal(await p.locator(".quantity").innerText(), "2");
  assert.equal(await p.locator("#cart-total").innerText(), total);
  return { quantity: 2, persistedTotal: total };
});
await check("cart-two-tabs-detect-conflict-and-reload", async (p, c) => {
  await login(c);
  await clearCart(c);
  await add(c);
  await p.goto(base + "/store/cart");
  const other = await c.newPage();
  await other.goto(base + "/store/cart");
  await p.locator(".increase").click();
  await p.waitForFunction(() => document.querySelector(".quantity")?.textContent === "2");
  await other.locator(".increase").click();
  await other.waitForFunction(() => document.querySelector("#cart-error")?.textContent.includes("409"));
  assert.equal(await other.locator(".quantity").innerText(), "1");
  await other.locator("#cart-reload").click();
  await other.waitForFunction(() => document.querySelector(".quantity")?.textContent === "2");
  return { conflict: 409, reloaded: 2 };
});
await check("remove-last-cart-line-renders-empty-state", async (p, c) => {
  await login(c);
  await clearCart(c);
  await add(c);
  await p.goto(base + "/store/cart");
  await p.locator(".remove-item").click();
  await p.locator("#empty-cart").waitFor();
  assert.equal(await p.locator("[data-cart-sku]").count(), 0);
  assert.ok(await p.locator("#place-order").isDisabled());
  return { empty: true };
});
await check("checkout-ajax-and-reload-do-not-duplicate-order", async (p, c) => {
  await login(c);
  await clearCart(c);
  await add(c, "sku-3");
  await p.goto(base + "/store/cart");
  await p.locator('input[name="email"]').fill("alice@alpha.test");
  await p.locator('textarea[name="address"]').fill("123 Demo Street");
  await p.locator("#place-order").click();
  await p.waitForURL(/\/store\/orders\//);
  const id = await p.locator("#order-id").innerText();
  await p.reload();
  assert.equal(await p.locator("#order-id").innerText(), id);
  assert.equal((await api(c, "/store/api/cart")).data.items.length, 0);
  return { savedOrder: true, reloadStable: true };
});
await check(
  "checkout-native-without-javascript",
  async (p, c) => {
    await login(c, "editor@alpha.test");
    await clearCart(c);
    await add(c, "sku-4");
    await p.goto(base + "/store/cart");
    await p.locator('input[name="email"]').fill("editor@alpha.test");
    await p.locator('textarea[name="address"]').fill("24 Example Road");
    await p.locator("#place-order").click();
    await p.waitForURL(/\/store\/orders\//);
    assert.ok(await p.locator("#order-id").innerText());
    return { nativeCheckout: true };
  },
  { javaScriptEnabled: false },
);
await check("tenant-inbox-navigation-and-filter", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk");
  assert.equal(await p.locator("[data-ticket]").count(), 6);
  await p.screenshot({ path: new URL("../results/sites/casework.png", import.meta.url).pathname, fullPage: false });
  await p.locator("#ticket-search").fill("Invoice");
  await p.locator("button").filter({ hasText: "Filter" }).click();
  assert.equal(await p.locator("[data-ticket]").count(), 1);
  await p.locator("[data-ticket] h2").click();
  await p.waitForURL(/\/desk\/tickets\/alpha-2/);
  return { filtered: 1 };
});
await check("ticket-edit-persists-and-two-tab-conflict-keeps-text", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk/tickets/alpha-3");
  const other = await c.newPage();
  await other.goto(base + "/desk/tickets/alpha-3");
  await p.locator("#ticket-title").fill("Updated export request");
  await p.locator("#ticket-status").selectOption("pending");
  await p.locator("#save-ticket").click();
  await p.waitForFunction(() => document.querySelector("#ticket-feedback")?.textContent === "Saved");
  await other.locator("#ticket-title").fill("My conflicting draft");
  await other.locator("#save-ticket").click();
  await other.waitForFunction(() => document.querySelector("#ticket-feedback")?.textContent.includes("409"));
  assert.equal(await other.locator("#ticket-title").inputValue(), "My conflicting draft");
  await p.reload();
  assert.equal(await p.locator("#ticket-title").inputValue(), "Updated export request");
  return { persisted: true, conflictKeptDraft: true };
});
await check("live-conversation-two-tabs-no-duplicate-message", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk/tickets/alpha-4");
  const other = await c.newPage();
  await other.goto(base + "/desk/tickets/alpha-4");
  await other.waitForFunction(() => document.querySelector("#live-connection")?.textContent === "Live");
  const text = "A live support reply " + Date.now();
  await p.locator("#reply-body").fill(text);
  await p.locator("#send-reply").click();
  await other.locator(".message p").filter({ hasText: text }).waitFor();
  assert.equal(await other.locator(".message p").filter({ hasText: text }).count(), 1);
  assert.equal(await p.locator(".message p").filter({ hasText: text }).count(), 1);
  return { deliveredToSecondTab: true, duplicate: false };
});
await check("attachment-upload-and-authenticated-download", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk/tickets/alpha-5");
  await p.locator("#attachment").setInputFiles({ name: "browser-note.txt", mimeType: "text/plain", buffer: Buffer.from("Local attachment evidence") });
  await p.locator("#upload-file").click();
  const link = p.locator(".file-download").filter({ hasText: "browser-note.txt" });
  await link.waitFor();
  const pending = p.waitForEvent("download");
  await link.click();
  const download = await pending;
  assert.equal(download.suggestedFilename(), "browser-note.txt");
  assert.equal(await download.failure(), null);
  return { downloaded: true };
});
await check("viewer-controls-disabled-and-direct-admin-denied", async (p, c) => {
  await login(c, "viewer@alpha.test");
  await p.goto(base + "/desk/tickets/alpha-1");
  assert.ok(await p.locator("#ticket-title").isDisabled());
  assert.ok(await p.locator("#send-reply").isDisabled());
  assert.equal((await p.goto(base + "/desk/admin")).status(), 403);
  return { disabled: true, adminStatus: 403 };
});
await check("editor-autosaves-and-reloads-from-database", async (p, c) => {
  await login(c, "editor@alpha.test");
  await p.goto(base + "/desk/editor");
  const text = "A durable editorial draft " + Date.now();
  const saved = p.waitForResponse((r) => r.url().endsWith("/desk/api/draft") && r.request().method() === "PUT");
  await p.locator("#draft-body").fill(text);
  assert.equal((await saved).status(), 200);
  await p.waitForFunction(() => document.querySelector("#draft-status")?.textContent === "Saved");
  await p.reload();
  assert.equal(await p.locator("#draft-body").inputValue(), text);
  return { persisted: true };
});
await check("editor-conflict-preserves-unsaved-local-story", async (p, c) => {
  await login(c, "editor@alpha.test");
  await p.goto(base + "/desk/editor");
  const other = await c.newPage();
  await other.goto(base + "/desk/editor");
  const saved = p.waitForResponse((r) => r.url().endsWith("/desk/api/draft") && r.request().method() === "PUT");
  await p.locator("#draft-title").fill("First tab saved title");
  await saved;
  await other.locator("#draft-body").fill("Do not lose the other tab text");
  await other.locator("#save-draft").click();
  await other.waitForFunction(() => document.querySelector("#draft-status")?.textContent.includes("409"));
  assert.equal(await other.locator("#draft-body").inputValue(), "Do not lose the other tab text");
  return { conflict: true, localStoryPreserved: true };
});
await check("editor-network-failure-and-explicit-retry", async (p, c) => {
  await login(c, "editor@alpha.test");
  await p.goto(base + "/desk/editor");
  await p.route("**/desk/api/draft", (r) => (r.request().method() === "PUT" ? r.abort("failed") : r.continue()));
  await p.locator("#draft-body").fill("Retained while network is down");
  await p.locator("#save-draft").click();
  await p.waitForFunction(() => document.querySelector("#draft-status")?.textContent.includes("fetch"));
  assert.equal(await p.locator("#draft-body").inputValue(), "Retained while network is down");
  await p.unroute("**/desk/api/draft");
  const retried = p.waitForResponse((r) => r.url().endsWith("/desk/api/draft") && r.request().method() === "PUT");
  await p.locator("#save-draft").click();
  assert.equal((await retried).status(), 200);
  await p.reload();
  assert.equal(await p.locator("#draft-body").inputValue(), "Retained while network is down");
  return { recovered: true };
});
const payloads = [
  '<img src=x onerror="globalThis.__attack=1">',
  "</script><script>globalThis.__attack=1</script>",
  '"><svg onload="globalThis.__attack=1">',
  "&lt;img src=x onerror=globalThis.__attack=1&gt;",
];
for (let i = 0; i < payloads.length; i++)
  await check("stored-XSS-draft-payload-" + i, async (p, c) => {
    await login(c, "editor@alpha.test");
    const draft = (await api(c, "/desk/api/draft")).data;
    const result = await api(c, "/desk/api/draft", "PUT", { version: draft.version, title: "Untrusted title " + payloads[i], body: payloads[i] });
    assert.equal(result.status, 200);
    await p.goto(base + "/desk/editor");
    assert.equal(await p.locator("#preview-body").innerText(), payloads[i]);
    assert.equal(await p.locator("#preview-body img,#preview-body svg,#preview-body script").count(), 0);
    assert.equal(await p.evaluate(() => globalThis.__attack), undefined);
    await p.locator("#draft-body").fill(payloads[i] + " client");
    assert.equal(await p.evaluate(() => globalThis.__attack), undefined);
    return { payload: i, executed: false };
  });
await check("stored-XSS-chat-is-text-after-SSE", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk/tickets/alpha-6");
  await p.waitForFunction(() => document.querySelector("#live-connection")?.textContent === "Live");
  const payload = payloads[0] + " live-" + Date.now();
  assert.equal(await p.locator(".message p").filter({ hasText: payload }).count(), 0);
  await api(c, "/desk/api/messages/alpha-6", "POST", { body: payload });
  await p.locator(".message p").filter({ hasText: payload }).waitFor();
  assert.equal(await p.locator(".message img").count(), 0);
  assert.equal(await p.evaluate(() => globalThis.__attack), undefined);
  return { executed: false };
});
await check("reflected-XSS-query-does-not-escape-input", async (p) => {
  await p.goto(base + "/store?q=" + encodeURIComponent(payloads[2]));
  assert.equal(await p.locator("#shop-search").inputValue(), payloads[2]);
  assert.equal(await p.evaluate(() => globalThis.__attack), undefined);
  return { executed: false };
});
await check("logout-back-reload-cannot-reopen-private-workspace", async (p, c) => {
  await login(c);
  await p.goto(base + "/desk/editor");
  await p.locator("#logout").click();
  await p.waitForURL(/\/sign-in/);
  await p.goBack();
  assert.ok(!(await p.locator("body").innerText()).includes("PRIVATE DRAFT"), "Back must not restore the private editor after logout");
  await p.reload();
  assert.ok(!(await p.locator("body").innerText()).includes("PRIVATE DRAFT"));
  assert.equal((await c.request.get(base + "/desk")).status(), 401);
  return { deniedAfterLogout: true };
});
await check("dispatch-search-pagination-story-and-history", async (p) => {
  await p.goto(base + "/dispatch");
  await p.screenshot({ path: new URL("../results/sites/dispatch.png", import.meta.url).pathname, fullPage: false });
  await p.locator("#article-search").fill("security");
  await p.locator("#article-filter").click();
  await p.waitForURL(/q=security/);
  assert.equal(await p.locator(".article-card").count(), 6);
  await p.locator("#article-next").click();
  await p.waitForFunction(() => document.querySelector("#article-page")?.textContent === "Page 2 of 2");
  const title = await p.locator(".article-card h2").first().innerText();
  await p.locator(".read-story").first().click();
  await p.waitForURL(/\/dispatch\/dispatch-/);
  assert.equal(await p.locator("#story-title").innerText(), title);
  assert.ok((await p.title()).includes(title));
  await p.goBack();
  assert.equal(await p.locator("#article-page").innerText(), "Page 2 of 2");
  return { search: true, pagination: true, articleTitle: true, history: true };
});
await check(
  "public-article-works-without-javascript",
  async (p) => {
    await p.goto(base + "/dispatch/dispatch-1");
    assert.match(await p.locator("#story-title").innerText(), /Security/);
    assert.ok((await p.locator(".article-prose").innerText()).includes("Permissions"));
    return { SSR: true };
  },
  { javaScriptEnabled: false },
);
await check(
  "mobile-workspace-and-editor-do-not-overflow",
  async (p, c) => {
    await login(c);
    await p.goto(base + "/desk/editor");
    assert.ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    return { width: 390 };
  },
  { viewport: { width: 390, height: 844 } },
);
await browser.close();
await writeFile(new URL("../results/journeys.json", import.meta.url), JSON.stringify(results, null, 2));
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
