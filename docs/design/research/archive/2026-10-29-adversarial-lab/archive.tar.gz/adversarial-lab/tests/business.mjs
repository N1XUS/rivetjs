import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
const directory = await mkdtemp(join(tmpdir(), "rivet-real-services-"));
process.env.LAB_DB = join(directory, "db.sqlite");
const s = await import("../src/sites/service.server.ts");
const results = [];
async function check(name, fn) {
  try {
    results.push({ name, layer: "application-service", pass: true, observed: await fn() });
  } catch (e) {
    results.push({ name, layer: "application-service", pass: false, error: e.message });
  }
  console.log(`${results.at(-1).pass ? "PASS" : "FAIL"} ${name}`);
}
const alice = s.authenticate("alice@alpha.test", "demo-pass-2026"),
  bob = s.authenticate("bob@beta.test", "demo-pass-2026"),
  viewer = s.authenticate("viewer@alpha.test", "demo-pass-2026");
await check("valid-login-and-wrong-password", () => {
  assert.equal(alice.tenant, "alpha");
  assert.equal(s.authenticate("alice@alpha.test", "wrong"), null);
});
await check("unknown-user-and-sql-injection-login", () => {
  assert.equal(s.authenticate("' OR 1=1--", "anything"), null);
});
await check("session-generated-and-revoked-server-side", () => {
  const token = s.createSession(alice);
  assert.equal(s.sessionUser(token).id, alice.id);
  s.revokeSession(token);
  assert.equal(s.sessionUser(token), null);
});
await check("expired-session-rejected", () => {
  const token = s.createSession(alice, -1);
  assert.equal(s.sessionUser(token), null);
});
await check("cross-tenant-ticket-read-hidden", () => {
  assert.equal(s.ticketFor(bob, "alpha-1"), null);
});
await check("cross-tenant-ticket-write-denied", () => {
  assert.throws(
    () => s.updateTicket(bob, "alpha-1", { version: 0, status: "closed" }),
    (e) => e.status === 404,
  );
});
await check("viewer-cannot-mutate-ticket", () => {
  assert.throws(
    () => s.updateTicket(viewer, "alpha-1", { version: 0, status: "closed" }),
    (e) => e.status === 403,
  );
});
await check("optimistic-version-conflict", () => {
  let t = s.ticketFor(alice, "alpha-1");
  const next = s.updateTicket(alice, t.id, { version: t.version, status: "pending" });
  assert.equal(next.version, t.version + 1);
  assert.throws(
    () => s.updateTicket(alice, t.id, { version: t.version, status: "closed" }),
    (e) => e.status === 409,
  );
});
await check("mass-assignment-tenant-and-role-denied", () => {
  assert.throws(
    () => s.updateTicket(alice, "alpha-1", { version: 1, tenant: "beta", role: "admin" }),
    (e) => e.status === 400,
  );
});
await check("cart-computes-prices-from-server-catalog", () => {
  const c = s.cartFor(alice);
  const next = s.setCart(alice, { version: c.version, sku: "sku-1", quantity: 2 });
  assert.equal(next.subtotal, 2 * s.productFor("sku-1").price);
});
await check("cart-price-tampering-rejected", () => {
  const c = s.cartFor(alice);
  assert.throws(
    () => s.setCart(alice, { version: c.version, sku: "sku-1", quantity: 2, price: 1 }),
    (e) => e.status === 400,
  );
});
await check("negative-and-fractional-quantities-denied", () => {
  for (const quantity of [-1, 0.5, 100000])
    assert.throws(
      () => s.setCart(alice, { version: s.cartFor(alice).version, sku: "sku-1", quantity }),
      (e) => e.status === 400,
    );
});
await check("checkout-is-idempotent-and-clears-cart", () => {
  const c = s.cartFor(alice);
  const a = s.checkout(alice, { version: c.version, key: "unit-checkout" }),
    b = s.checkout(alice, { version: c.version, key: "unit-checkout" });
  assert.equal(a.id, b.id);
  assert.equal(s.cartFor(alice).items.length, 0);
});
await check("order-cannot-be-read-across-users", () => {
  const order = s.ordersFor(alice)[0];
  assert.equal(s.orderFor(bob, order.id), null);
});
await check("draft-conflict-does-not-overwrite-text", () => {
  const d = s.draftFor(alice);
  s.saveDraft(alice, { version: d.version, title: "First", body: "Keep me" });
  assert.throws(
    () => s.saveDraft(alice, { version: d.version, title: "Second", body: "Overwrite" }),
    (e) => e.status === 409,
  );
  assert.equal(s.draftFor(alice).body, "Keep me");
});
await check("public-article-filter-and-pagination", () => {
  const page = s.articlePage({ q: "security", page: 1 });
  assert.ok(page.total > 0);
  assert.ok(page.items.every((a) => a.title.toLowerCase().includes("security")));
});
await check("event-feed-is-tenant-scoped", () => {
  s.addMessage(alice, "alpha-1", "alpha-private");
  assert.ok(s.eventsFor(alice, 0).some((e) => e.body.includes("alpha-private")));
  assert.ok(!s.eventsFor(bob, 0).some((e) => e.body.includes("alpha-private")));
});
await check("upload-traversal-and-active-content-denied", () => {
  for (const filename of ["../../secret.txt", "evil.html", "evil.svg", "a\\b.txt"])
    assert.throws(
      () => s.addFile(alice, "alpha-1", filename, "text/plain", Buffer.from("x")),
      (e) => e.status === 400,
    );
});
await check("attachment-is-tenant-scoped", () => {
  const f = s.addFile(alice, "alpha-1", "note.txt", "text/plain", Buffer.from("safe"));
  assert.equal(s.fileFor(bob, f.id), null);
  assert.equal(s.fileFor(alice, f.id).name, "note.txt");
});
await check("return-path-rejects-controls-and-external-origins", () => {
  for (const value of ["/\t/attacker.invalid", "/\n/attacker.invalid", "//attacker.invalid", "/\\attacker.invalid", "https://attacker.invalid"])
    assert.equal(s.nextPath(value), "/desk");
  assert.equal(s.nextPath("/desk/editor?mode=preview"), "/desk/editor?mode=preview");
});
await writeFile(new URL("../results/business.json", import.meta.url), JSON.stringify(results, null, 2));
s.closeDatabase();
await rm(directory, { recursive: true, force: true });
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
