import assert from "node:assert/strict";
import { chromium } from "playwright";
import { mkdir, writeFile } from "node:fs/promises";
const base = process.env.LAB_URL ?? "http://127.0.0.1:4488";
const browser = await chromium.launch({ headless: true });
const results = [];
async function check(name, fn, path = "/") {
  const page = await browser.newPage();
  page.setDefaultTimeout(6000);
  page.setDefaultNavigationTimeout(10000);
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  try {
    await page.goto(base + path);
    const observed = await fn(page);
    assert.deepEqual(errors, []);
    results.push({ name, pass: true, observed, errors });
  } catch (e) {
    await page.screenshot({ path: new URL(`../results/${name}.png`, import.meta.url).pathname, fullPage: true });
    results.push({ name, pass: false, error: e.message, errors, body: (await page.locator("body").innerText()).slice(0, 5000) });
  } finally {
    console.log(`${results.at(-1).pass ? "PASS" : "FAIL"} ${name}`);
    await page.close();
  }
}
await mkdir(new URL("../results/", import.meta.url), { recursive: true });
await check("cold-click-batch-and-derived-total", async (p) => {
  await p.locator("#increment").click();
  await p.waitForFunction(() => document.querySelector("#counter")?.textContent === "1");
  assert.equal(await p.locator("#double").textContent(), "2");
  return { count: 1, double: 2 };
});
await check("store-index-extension-ui-consistency", async (p) => {
  await p.locator("#extend-array").click();
  await p.waitForFunction(() => document.querySelector("#actual-length")?.textContent === "4");
  assert.equal(await p.locator("#tracked-length").textContent(), "4");
  return { length: 4 };
});
await check("store-truncate-ui-consistency", async (p) => {
  await p.locator("#truncate-array").click();
  await p.waitForFunction(() => document.querySelector("#actual-length")?.textContent === "1");
  assert.equal(await p.locator("#second-item").textContent(), "absent");
  return { length: 1 };
});
await check("typed-produce-read-then-truncate", async (p) => {
  await p.locator("#produce-truncate").click();
  await p.waitForTimeout(100);
  assert.equal(await p.locator("#produce-length").textContent(), "0");
  assert.equal(await p.locator("#produce-second").textContent(), "absent");
  return { length: 0 };
});
await check("keyed-reorder-preserves-local-input-and-node", async (p) => {
  const input = p.locator('[data-row="1"] input');
  await input.fill("unsaved draft");
  await input.evaluate((e) => {
    globalThis.__labNode = e;
  });
  await p.locator("#reverse").click();
  await p.waitForFunction(() => document.querySelector("#incidents tr")?.getAttribute("data-row") === "120");
  assert.equal(await p.locator('[data-row="1"] input').inputValue(), "unsaved draft");
  assert.ok(await p.locator('[data-row="1"] input').evaluate((e) => e === globalThis.__labNode));
  return { sameNode: true };
});
await check("nested-conditional-keyed-children", async (p) => {
  await p.locator('[data-row="1"] .expand').click();
  await p.waitForFunction(() => document.querySelector('[data-note="1-1"]'));
  await p.locator("#reverse").click();
  await p.locator('[data-row="1"] .add-note').click();
  await p.waitForFunction(() => document.querySelectorAll('[data-row="1"] [data-note]').length === 3);
  return { notes: 3 };
});
await check("filter-conditional-empty-restore", async (p) => {
  await p.locator("#filter").fill("does-not-exist");
  await p.waitForFunction(() => document.querySelectorAll("#incidents tr").length === 0);
  assert.equal(await p.locator("#empty").textContent(), "No incidents");
  await p.locator("#filter").fill("Incident 001");
  await p.waitForFunction(() => document.querySelectorAll("#incidents tr").length === 1);
  return { rows: 1 };
});
await check("resource-race-latest-response-wins", async (p) => {
  await p.locator("#slow-search").click();
  await p.locator("#fast-search").click();
  await p.waitForFunction(() => document.querySelector("#search-result")?.textContent === "fast");
  await p.waitForTimeout(350);
  assert.equal(await p.locator("#search-result").textContent(), "fast");
  return { result: "fast" };
});
await check("resource-error-recovers", async (p) => {
  await p.locator("#error-search").click();
  await p.waitForFunction(() => document.querySelector("#search-state")?.textContent === "errored");
  await p.locator("#fast-search").click();
  await p.waitForFunction(() => document.querySelector("#search-result")?.textContent === "fast");
  return { recovered: true };
});
await check("sse-websocket-and-owner-cleanup", async (p) => {
  await p.locator("#connect").click();
  await p.waitForFunction(
    () => Number(document.querySelector("#sse-count")?.textContent) >= 3 && Number(document.querySelector("#ws-count")?.textContent) >= 3,
  );
  await p.locator("#connect").click();
  await p.waitForTimeout(250);
  const stats = await (await fetch(base + "/api/stats")).json();
  assert.equal(stats.sseActive, 0);
  assert.equal(stats.wsActive, 0);
  return stats;
});
await check("controlled-select-textarea-model", async (p) => {
  await p.locator("#editor-text").fill("edited\nsecond line");
  await p.locator("#severity").selectOption("critical");
  await p.waitForFunction(() => document.querySelector("#editor-output")?.textContent === "critical:edited\nsecond line");
  return { models: true };
});
await check(
  "rich-loader-data-survives-resume",
  async (p) => {
    await p.locator("#rich-click").click();
    await p.waitForFunction(() => document.querySelector("#rich-counter")?.textContent === "1");
    assert.equal(await p.locator("#rich-value").textContent(), "2026-01-02T00:00:00.000Z|42|7|true");
    return { rich: true };
  },
  "/rich",
);
await check(
  "live-navigation-preserves-draft-and-refreshes-rows",
  async (p) => {
    await p.locator("#live-draft").fill("keep me");
    await p.locator("#live-next").click();
    await p.waitForFunction(() => document.querySelector("#live-page")?.textContent === "2");
    assert.equal(await p.locator("#live-draft").inputValue(), "keep me");
    return { page: 2, draft: "keep me" };
  },
  "/live",
);
await check(
  "async-load-retracks-source-after-resume",
  async (p) => {
    await p.locator("#async-next").click();
    await p.waitForFunction(() => document.querySelector("#async-source")?.textContent === "2");
    await p.waitForFunction(() => document.querySelector("#resource-result")?.textContent === "2");
    await p.waitForTimeout(100);
    assert.equal(await p.locator("#async-result").textContent(), "2");
    return { async: 2, resource: 2 };
  },
  "/async",
);
await check(
  "error-boundary-catches-binding-and-resets",
  async (p) => {
    await p.locator("#break-widget").click();
    await p.locator("#caught").waitFor();
    await p.locator("#recover-widget").click();
    await p.locator("#healthy").waitFor();
    assert.equal(await p.locator("#healthy").textContent(), "healthy");
    return { recovered: true };
  },
  "/errors",
);
await writeFile(new URL("../results/browser.json", import.meta.url), JSON.stringify(results, null, 2));
for (const r of results) console.log(`${r.pass ? "PASS" : "FAIL"} ${r.name}${r.pass ? "" : `: ${r.error}`}`);
await browser.close();
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
