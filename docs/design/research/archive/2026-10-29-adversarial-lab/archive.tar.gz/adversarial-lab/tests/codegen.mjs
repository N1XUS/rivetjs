import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";
import { scanRoutes } from "../../libs/router/build/routes.ts";
import { generate } from "../../libs/router/build/codegen.ts";
const table = await scanRoutes(new URL("../src/routes", import.meta.url).pathname);
assert.equal(table.routes.find((r) => r.id === "live").live, true);
const results = [];
for (const navigate of [false, true]) {
  const { files } = generate(table, { routesDir: "src/routes", navigate });
  const app = files["app.tsx"];
  const accessor = app.includes("const live = _live(");
  results.push({ name: "live-page-must-receive-accessor", navigate, pass: accessor, hasLiveRoute: true, hasLiveAccessor: accessor });
  await writeFile(new URL(`../results/generated-navigate-${navigate}.txt`, import.meta.url), app);
  console.log(`${accessor ? "PASS" : "FAIL"} live accessor with navigate=${navigate}`);
}
await writeFile(new URL("../results/codegen.json", import.meta.url), JSON.stringify(results, null, 2));
process.exitCode = results.some((r) => !r.pass) ? 1 : 0;
