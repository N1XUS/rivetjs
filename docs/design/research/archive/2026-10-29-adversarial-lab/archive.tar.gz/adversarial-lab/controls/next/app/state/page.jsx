"use client";
import { useState } from "react";
export default function State() {
  const [state, setState] = useState({ items: [{ n: 1 }, { n: 2 }] });
  return (
    <main>
      <h1>React immutable state control</h1>
      <button
        id="produce-truncate"
        onClick={() =>
          setState((previous) => {
            const next = structuredClone(previous);
            void next.items[1].n;
            next.items.length = 0;
            return next;
          })
        }
      >
        Read then truncate
      </button>
      <output id="produce-length">{state.items.length}</output>
      <output id="produce-second">{state.items[1]?.n ?? "absent"}</output>
    </main>
  );
}
