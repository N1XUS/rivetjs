export default { experimental: { cpus: 1 }, distDir: ".next", poweredByHeader: false };
