"use client";
import { useState, useEffect } from "react";
export default function AsyncControl() {
  const [page, setPage] = useState(1),
    [value, setValue] = useState(1);
  useEffect(() => {
    let current = true;
    const timer = setTimeout(() => {
      if (current) setValue(page);
    }, 10);
    return () => {
      current = false;
      clearTimeout(timer);
    };
  }, [page]);
  return (
    <main>
      <h1>React reactive async control</h1>
      <button id="async-next" onClick={() => setPage((p) => p + 1)}>
        Next
      </button>
      <output id="async-source">{page}</output>
      <output id="async-result">{value}</output>
    </main>
  );
}
