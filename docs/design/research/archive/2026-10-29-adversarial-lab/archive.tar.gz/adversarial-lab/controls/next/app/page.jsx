import Live from "./live.jsx";
export const dynamic = "force-dynamic";
export default async function Page({ searchParams }) {
  const params = await searchParams;
  return <Live page={Number(params.page ?? "1")} />;
}
