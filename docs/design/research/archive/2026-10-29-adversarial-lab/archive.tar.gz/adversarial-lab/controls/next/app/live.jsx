"use client";
import { useState } from "react";
import Link from "next/link";
export default function Live({ page }) {
  const [draft, setDraft] = useState("");
  return (
    <main>
      <h1>Live routing</h1>
      <input id="live-draft" aria-label="Draft" value={draft} onChange={(e) => setDraft(e.target.value)} />
      <p id="live-page">{page}</p>
      <Link id="live-next" href="/?page=2">
        Next
      </Link>
    </main>
  );
}
