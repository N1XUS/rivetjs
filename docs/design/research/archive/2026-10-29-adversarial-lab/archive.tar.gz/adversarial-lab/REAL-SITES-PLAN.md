# Real sites + security expansion

Build on the CLI-created lab, without framework source changes. Selected approach: three coherent verticals sharing a real SQLite backend and synthetic accounts, with service tests, production HTTP security tests and browser journeys. Existing micro reproductions stay independently runnable. Scope is local authorized testing; no real users, payment providers or external targets.

- [ ] Write failing service and security/browser journey expectations first.
- [ ] SQLite services: sessions, tenant-aware tickets/messages/files, versioned drafts, catalog/cart/inventory/orders with atomic idempotent checkout.
- [ ] UI: Fieldshop catalog/cart/checkout; Casework tenant desk/ticket conversation/editor/admin; Dispatch public articles/search/pagination. Shared navigation, forms, actionable failures, responsive CSS.
- [ ] Security matrix: anonymous/forged/expired/revoked sessions; session rotation; HttpOnly; tenant IDOR read/write/download/events; role elevation/mass assignment; CSRF variants; reflected/stored XSS; private response caching/data endpoints; upload filename/type/size; client price tampering; parallel checkout/replay; unauthorized HTTP methods.
- [ ] Browser journeys: auth+logout+reload, filtered catalog and history, cart persistence and totals, two-tab version conflicts, checkout replay, ticket updates/live SSE across tabs, draft conflicts/autosave recovery, download attachment, public article URLs, mobile layout, JS-disabled form path.
- [ ] Attribute failures: app service tests establish policy independently; HTTP/browser failures are reduced before blaming Rivet. Existing probes and global feature detection can interact: record this explicitly.
- [ ] Integrate suites into one-command audit; archive the first report/results before replacing. Generate a coverage ledger and updated Ukrainian report with raw evidence and exact limitations.

Security references: OWASP WSTG authorization/IDOR/XSS/CSRF, OWASP Session Management Cheat Sheet. Passing app policy is not proof Rivet supplies it or a security certification. Synthetic passwords/local HTTP cookie exception must be explicit.
