> Архів першої хвилі. Поточні sources і runner вже розширені; ці результати описують попередній запуск.

# Rivet: технічний adversarial audit

У перевіреному workspace Rivet має **дві підтверджені помилки коректності**: `produce()` може мовчки скасувати видалення елементів масиву, а валідна live-сторінка — пройти check/build і повернути HTTP 500. Є також дві відтворені межі дизайну: втрата підписки `Async` після SSR і різний порядок авторизації для page handlers та endpoints.

Це конкретні підстави критикувати Rivet. Вони не доводять, що він гірший за React/Next/Solid у всьому. Складний інтеграційний стенд значну частину перевірок пройшов. Популярність і статус релізу не використовувалися як аргументи.

## Що саме перевірено

Проєкт створено локальним Rivet CLI:

```sh
node libs/create-rivet/cli.ts adversarial-lab --template server --yes --no-install --no-git --json
```

Стенд містить SSR-диспетчерську: до 5000 рядків, вкладені keyed списки, окремі чернетки рядків, signals/computed/batch/store, conditional rendering, textarea/select models, server action, Ajax із version conflict, `resource`, `Async`, `Suspense`, `ErrorBoundary`, live routing, deferred SSR, SSE і WebSocket через `ws` та HTTP server адаптера Rivet.

Контрольні версії: React **19.3.0**, Next **16.4.0**, Solid **1.9.15**; Node **26.5.1**, Chromium через Playwright **1.63.0**. Точний HEAD, незакомічені зміни, хеші джерел та середовище: [environment.json](results/phase1/environment.json). Це локальний workspace, який паралельно змінювався іншою роботою, а не сертифікація опублікованого пакета. Основні джерела перевіряються хешами до і після запуску.

Фінальний повний прогін: **36/49** основних очікувань пройшли, **13/49** впали. State/codegen додатково повторено тричі. `check`, Rivet build і Next build — exit 0; окремі React/Next/Solid controls — **4/4**, stress — **4/4**. Загальний exit 1 відповідає збереженим червоним assertions, інфраструктурних збоїв у фінальному прогоні немає. Хеші чотирьох основних джерел до/після збігаються (`criticalSourcesUnchanged: true`).

| Suite | Пройшли | Не пройшли |
| --- | ---: | ---: |
| State, Rivet + Solid | 6 | 5 |
| Codegen A/B | 1 | 1 |
| HTTP | 11 | 2 |
| Production browser | 10 | 5 |
| Окремі controls | 4 | 0 |
| Stress | 4 | 0 |

## 1. `produce()`: читання елемента змінює результат очищення масиву

**Клас:** помилка підтримуваного API; втрата коректності стану. Відтворюється без браузера й у production DOM. Код проходить TypeScript та `rivet-check`.

```ts
const state = createStore({ items: [{ n: 1 }, { n: 2 }] });
write(state, produce(draft => {
  void draft.items[1].n;
  draft.items.length = 0;
}));
console.log(read(state, "items"));
```

| Очікування | Rivet | Solid 1.9 `setStore(produce(...))` |
| --- | --- | --- |
| `items` стає `[]`, length = 0 | Залишається `[{n:1},{n:2}]`, length = 2 | `[]`, length = 0 |

Читання draft до видалення — звичайна операція: наприклад, перевірка останнього елемента перед очищенням черги. Вона не повинна скасовувати запис `length = 0`.

**Причина:** [store.ts](../libs/reactivity/store.ts#L301), `finalize()`. Раніше прочитаний дочірній draft залишається в `draft.children`. Фіналізація знову записує його в уже обрізану копію масиву через `into[key] = next`. Це відновлює довжину; порівняння written-полів може після цього визнати зміну відсутньою й повернути початковий масив.

**Докази:** [state.json](results/phase1/state.json), case `array-truncate-draft-does-not-resurrect-read-child`; [browser.json](results/phase1/browser.json), `typed-produce-read-then-truncate`; [production screenshot](results/phase1/typed-produce-read-then-truncate.png). Повторні малі прогони: [repeats.json](results/phase1/repeats.json).

React-контроль із `useState` та `structuredClone` також очищає масив: [controls.json](results/phase1/controls.json). Це інший механізм immutable update; пряме порівняння однойменного `produce` тут саме із Solid.

## 2. `live = true`: HTTP 500 через приховану залежність генерації від іншої можливості

**Клас:** помилка інтеграції routing/codegen. `npm run check` і production build проходять, але початковий GET `/live` повертає **500**.

Малий приклад — [live.tsx](src/routes/live.tsx): loader повертає номер сторінки, компонент приймає `LivePageProps`, читає `data().page`, має signal-чернетку й звичайний `<a>` для зміни query string.

```tsx
export const loader = load(({ url }: RequestEvent) => ({
  page: Number(url.searchParams.get("page") ?? "1")
}));
export const live = true;
export default function Page({ data }: LivePageProps<typeof loader>) {
  return <p>{data().page}</p>;
}
```

`data` на сервері виявляється звичайним об’єктом. Спроба викликати його завершується `TypeError: ... is not a function`.

**Причина:** [codegen.ts](../libs/router/build/codegen.ts#L343):

```ts
const go = options.navigate === true || forms;
const live = go && mode !== "csr" ? pageRoutes.filter(route => route.live) : [];
const pageData = live.length ? "data" : "result.data[depth]";
```

Прапорець live-сторінки розпізнано, але зміна типу її props застосовується лише коли ввімкнена ще й підтримка programmatic navigation/forms. Для сторінки зі звичайними посиланнями вона відсутня. Типізація цього протиріччя не знаходить.

**A/B генератора:** `navigate: false` — accessor відсутній; `navigate: true` — присутній. [codegen.json](results/phase1/codegen.json) і повні згенеровані тексти [false](results/phase1/generated-navigate-false.txt) / [true](results/phase1/generated-navigate-true.txt). Це підтверджує умову генерації; повний runtime workaround з іншим імпортом окремо не заявляється.

**Контроль Next/React:** production GET дає 200; після вводу `keep me` та переходу через `Link` до `?page=2` номер змінюється на 2, чернетка зберігається. [control source](controls/next/app/live.jsx), [controls.json](results/phase1/controls.json). Перевірено номер і чернетку, не еквівалентність усього router API. Офіційний опис [оновлення search parameters у Next](https://nextjs.org/docs/app/api-reference/functions/use-search-params).

Доказ HTTP 500: [http.json](results/phase1/http.json), `live-page-SSR-data-contract`; стек: [server.log](results/phase1/server.log). Browser timeout на відсутньому input — наслідок цього самого дефекту, не окрема помилка.

## 3. Після SSR `Async` залишає застарілі дані

**Клас:** задокументоване обмеження resumability, не новий невідомий баг.

У [async.tsx](src/routes/async.tsx) один signal використовується двома способами:

```tsx
<Async load={async () => {
  const key = page();
  await delay();
  return key;
}}>{n => <output>{n}</output>}</Async>
```

Після SSR та кліку `page` стає **2**, `resource` із reactive source показує **2**, а `Async` лишається на **1**. [browser.json](results/phase1/browser.json), `async-load-retracks-source-after-resume`; [screenshot](results/phase1/async-load-retracks-source-after-resume.png).

Під час adoption runtime повторно використовує SSR-результат і пропускає `load`, тому читання `page()` не створює браузерної підписки. Це прямо визнано в [документації Rivet](../apps/docs/content/guides/components/async.md#L92). Обхід — reactive outer expression або `resource`.

React `useEffect` із залежністю від номера і Solid `createResource` оновлюють результат до 2: [controls.json](results/phase1/controls.json). Це порівняння користувацького результату різними API. Воно показує додаткову пастку перенесення між SSR та клієнтом у Rivet; не доводить, що Rivet узагалі не підтримує reactive async — його `resource` цей тест проходить.

## 4. Layout guard не є загальною межею для page handlers

**Клас:** задокументований порядок виконання, важливий для проєктування авторизації. Не заявляється як знайдена уразливість стороннього застосунку або перевага над Next.

Один [layout guard](src/routes/private/_layout.tsx) вимагає cookie. Без cookie:

| Запит | Результат |
| --- | --- |
| `/private`, loader сторінки | 403 |
| `/private/export`, `onGet` у `.ts` endpoint | 403 |
| `/private/report`, `onGet` у `.tsx` сторінці | **200 + синтетичні приватні дані** |

[http.json](results/phase1/http.json), `enclosing-guard-protects-page-response-handler`. Усі дані тестові.

Причина: [handler.ts](../libs/router/server/handler.ts#L710) може повернути response page handler до циклу guards; власний handler endpoint викликається після guards. Це описано в [документації](../apps/docs/content/guides/routing/server-code-in-routes.md#L70). Перевірку доступу для такого page handler потрібно робити раніше або всередині нього. Прямий еквівалентний контроль авторизації Next не проводився.

## Додаткові результати, які не можна видати за головні докази

- Cached `items.length` лишається старим після запису за новим індексом; cached видалений індекс лишається видимим після запису в `length`. Це видно в Node та production UI. Але `StorePath` Rivet **не включає array length**, тому ці проби явно використовують type escape: [probes.ts](src/probes.ts). Це межа runtime-поведінки поза typed contract, не ще дві помилки підтримуваного API.
- `reconcile` втрачає trailing holes розрідженого масиву. **Solid 1.9 теж провалив цей тест.** Тому він не доводить, що Rivet гірший. Точні результати збережено в [state.json](results/phase1/state.json).
- Не рахую кількість червоних assertions як кількість незалежних дефектів: SSR 500 і browser timeout мають одну причину; Node і DOM `produce` перевіряють ту саму помилку.

## Що витримав Rivet

[HTTP](results/phase1/http.json), [browser](results/phase1/browser.json), [stress](results/phase1/stress.json):

- 40 паралельних SSR-відповідей з окремими синтетичними ідентичностями; екранування перевіреного HTML payload.
- Cold click, computed/batch, controlled textarea/select, Date/Map/Set/bigint у loader data після resume.
- Вкладені keyed lists: локальна чернетка та identity DOM-вузла при reorder; conditional empty state; error boundary та reset.
- **2000 рядків, 50 перестановок**, чотири незбережені чернетки й перевірка identity вузла.
- Ajax latest-response-wins і відновлення після помилки; 20 раундів із підтвердженням завершення кожного fast HTTP request.
- SSE: порядок восьми подій, закриття producer після abort. **20 циклів** SSE/WebSocket mount/unmount залишають нуль активних producers/connections. Це перевірка живих ресурсів, не доказ відсутності всіх heap leaks.
- Deferred SSR: shell у першому body chunk, payload у пізнішому; native POST action → 303; cross-origin POST → 403; повторний version → 409.
- Ввід при затримці JS chunks на 200 мс зберігається. Тест не встановлює точний момент вводу відносно доставки кожного чанка.

## Відтворення

Із кореня цього репозиторію, з наявними workspace dependencies та локальним pinned Next toolchain:

```sh
export PATH=/Users/denisseverin/.nvm/versions/node/v26.5.1/bin:$PATH
npm --prefix adversarial-lab run audit
```

Runner збирає обидва застосунки, піднімає localhost 4490/4491, запускає suites, повторює state/codegen три рази й закриває свої сервери. `LAB_PORT` / `NEXT_PORT` змінюють порти. **Exit 1 очікуваний:** assertions відтворюють дефекти та обмеження; **exit 2** означає збій інфраструктури. Окремі команди й запуск UI: [README](README.md).

Підсумок процесів: [run.json](results/phase1/run.json), [audit.log](results/phase1/audit.log). `check`/build і контрольні suites мають власні exit codes; червоні результати не приховано й не позначено passing.

Код фреймворку не виправлявся. Не вимірювалися throughput, p95, heap growth або перевага швидкодії над конкурентами; ці тести не є таким бенчмарком. Контрольний Next тут використовується для конкретної поведінки, не для оцінки його безпеки. Загальну стабільність великих production систем одним стендом встановити неможливо.
