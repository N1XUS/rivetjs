# Rivet adversarial lab

CLI-created production app and executable counterexamples against the current Rivet workspace. [Технічний звіт українською](REPORT.uk.md).

Run from the repository root, with its installed dependencies and Node >=24:

```sh
npm --prefix adversarial-lab run audit
```

The runner builds Rivet and the local pinned Next control, starts ports 4490/4491, runs all suites, saves JSON/logs in `results/`, repeats reduced state/codegen tests three times and stops its servers. Change ports with `LAB_PORT` / `NEXT_PORT`. It uses the Next installation in `apps/bridge-demo/next` (or `controls/next/node_modules/next`) and Solid 1.9 in `apps/bench-stable`. It performs no installation and changes no framework source.

Exit **1** records failed correctness expectations. Exit **2** records infrastructure failure. `results/run.json` lists actual subprocess exits; fresh result JSON is required from each suite, so a crashed process cannot reuse stale evidence.

Individual suites, from repo root:

```sh
node --conditions=browser adversarial-lab/tests/state.mjs
node adversarial-lab/tests/codegen.mjs
LAB_URL=http://127.0.0.1:4488 node adversarial-lab/tests/http.mjs
LAB_URL=http://127.0.0.1:4488 node adversarial-lab/tests/browser.mjs
LAB_URL=http://127.0.0.1:4488 node adversarial-lab/tests/stress.mjs
NEXT_URL=http://127.0.0.1:4489 node --conditions=browser adversarial-lab/tests/controls.mjs
```

To inspect the app manually (separate terminal):

```sh
npm --prefix adversarial-lab run build
cd adversarial-lab
PORT=4488 npm start
```

Open `http://127.0.0.1:4488`. Default: 120 incidents; `/?count=2000` or `/?count=5000` increases load. `/async` shows the SSR Async/resource difference, `/live` reproduces the live-page SSR error, `/errors` tests boundary recovery, `/rich` tests loader serialization, `/stream` shows deferred SSR.

The app uses an in-memory backend and synthetic data. WebSockets integrate `ws` through the Node adapter's exposed server. Length-path probes cross Rivet's TypeScript contract explicitly; sparse-array reconcile also fails the Solid control. These are distinguished from supported-API defects in the report. React immutable-updater and async controls use idiomatic React APIs, not Rivet's exact API.

No speed ranking, heap-leak certification, security certification or population-wide framework verdict is implied. See `PLAN.md`, `LAB-NOTES.md` and raw results for exact scope.
