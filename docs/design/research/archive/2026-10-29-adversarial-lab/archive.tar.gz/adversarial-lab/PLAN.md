# Rivet adversarial lab

Goal: find reproducible correctness failures, with React 19 / Next 16 and Solid 1.9 controls where equivalent. The requested outcome is evidence, not a predetermined verdict.

Architecture: CLI-created server starter, production build, a live incident dashboard, independent HTTP/browser/state runners. Do not change framework code or existing WIP. Use local installed toolchains; record versions, commit and dirty paths. No external services or real user data.

Alternatives: existing microbenchmarks provide performance data but little integrated correctness coverage; a huge app alone obscures root causes. Selected approach: integrated app plus reduced counterexamples and positive controls.

- [x] State tests first: nested paths, array extension/truncation, immutable drafts, structural reconcile, batching; compare expected JS semantics and Solid.
- [x] Build the operations dashboard: nested keyed rows, local edits, filtering, conditionals, forms, live routing, Ajax resource races, error recovery, SSE and WebSocket lifecycle.
- [x] HTTP tests: SSR escaping/isolation, rich loader data, guard ordering, CSRF, request cancellation, streaming. Native HTTP control for stream cancellation was not added: Rivet's disconnect path passes, and no cancellation defect or comparative claim is made.
- [x] Production browser tests: cold interaction, node identity, typed input, nested keyed reorder, transport messages and unmount, resource latest wins and error recovery.
- [x] React / Next / Solid controls for actual findings. Guard ordering has no Next differential control and is reported only as documented behavior. Control API differences remain explicit.
- [x] Save raw JSON, logs and environment metadata; rerun reduced state/codegen failures three times; write Ukrainian report with exact commands, expected/actual, scope and untested cases.

Review focus: array implicit mutations; stale async completions; cold resumability versus already-active DOM; abort propagation across Node/Web boundaries; guard ordering on response-producing handlers. Each must have executable coverage.

Run from repo root with Node 26 path from root CLAUDE.md. The lab uses the workspace snapshot, not a published-release claim. Intentionally failing expectations are evidence and must remain failing.
