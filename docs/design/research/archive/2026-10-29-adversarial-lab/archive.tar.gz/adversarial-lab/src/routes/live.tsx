import { load, type RequestEvent, type LivePageProps } from "@rivetjs/router";
import { signal } from "@rivetjs/reactivity";
import { For } from "@rivetjs/runtime/dom";
export const loader = load(({ url }: RequestEvent) => ({
  page: Number(url.searchParams.get("page") ?? "1"),
  rows: [1, 2, 3].map((i) => ({ id: i, text: `Page ${url.searchParams.get("page") ?? "1"} row ${i}` })),
}));
export const live = true;
export default function Live({ data }: LivePageProps<typeof loader>) {
  const draft = signal("");
  return (
    <main>
      <h1>Live routing</h1>
      <input id="live-draft" aria-label="Draft" model:value={draft} />
      <p id="live-page">{data().page}</p>
      <a id="live-next" href="/live?page=2">
        Next
      </a>
      <ul>
        <For each={data().rows} by={(r) => r.id}>
          {(r) => <li>{r().text}</li>}
        </For>
      </ul>
    </main>
  );
}
