import { signal, computed, batch } from "@rivetjs/reactivity";
import { createStore, read, write, produce } from "@rivetjs/reactivity/store";
import { For, Show } from "@rivetjs/runtime/dom";
import { load, actions, redirect, type PageProps, type RequestEvent } from "@rivetjs/router";
import { incidents } from "../model.ts";
import { IncidentRow } from "../components/IncidentRow.tsx";
import { Search } from "../components/Search.tsx";
import { Transports } from "../components/Transports.tsx";
import { backend } from "../backend.server.ts";
import { trackedArrayLength, truncateArray } from "../probes.ts";
export const loader = load(({ url }: RequestEvent) => ({ incidents: incidents(Math.max(1, Math.min(5000, Number(url.searchParams.get("count") ?? "120")))) }));
export const forms = actions({
  add: async ({ request }: RequestEvent) => {
    const title = String((await request.formData()).get("title") ?? "");
    backend.titles.push(title);
    return redirect("/", 303);
  },
});
export const head = { title: "Rivet adversarial operations lab" };
export default function Dashboard({ data }: PageProps<typeof loader>) {
  const counter = signal(0),
    double = computed(() => counter() * 2),
    rows = signal(data.incidents),
    filter = signal(""),
    connected = signal(false);
  const visible = computed(() => rows().filter((r) => r.title.toLowerCase().includes(filter().toLowerCase())));
  const array = createStore({ items: [{ n: 1 }, { n: 2 }] });
  const severity = signal("normal"),
    text = signal("initial text");
  const draftStore = createStore({ items: [{ n: 1 }, { n: 2 }] });
  return (
    <main>
      <h1>Incident operations</h1>
      <p>Production SSR, resumability, nested keyed state, Ajax, SSE and WebSocket.</p>
      <nav>
        <a href="/live">Live routing</a> <a href="/rich">Rich data</a> <a href="/private">Protected page</a> <a href="/stream">SSR stream</a>
      </nav>
      <section>
        <h2>Cold events / batch</h2>
        <button id="increment" onClick={() => batch(() => counter.update((n) => n + 1))}>
          Increment
        </button>
        <output id="counter">{counter()}</output>
        <output id="double">{double()}</output>
      </section>
      <section>
        <h2>Store consistency probes (length paths require a type escape)</h2>
        <button id="extend-array" onClick={() => write(array, "items.3", { n: 4 })}>
          Extend via index
        </button>
        <button id="truncate-array" onClick={() => truncateArray(array)}>
          Truncate via length
        </button>
        <p>
          Whole array length: <output id="actual-length">{read(array, "items").length}</output>; tracked length:{" "}
          <output id="tracked-length">{trackedArrayLength(array)}</output>; second item:{" "}
          <output id="second-item">{read(array, "items.1.n") ?? "absent"}</output>
        </p>
      </section>
      <section>
        <h2>Fully typed produce regression</h2>
        <button
          id="produce-truncate"
          onClick={() =>
            write(
              draftStore,
              produce((d) => {
                void d.items[1].n;
                d.items.length = 0;
              }),
            )
          }
        >
          Read then truncate draft
        </button>
        <output id="produce-length">{read(draftStore, "items").length}</output>
        <output id="produce-second">{read(draftStore, "items.1.n") ?? "absent"}</output>
      </section>
      <Search />
      <section>
        <h2>Transport lifecycle</h2>
        <button id="connect" onClick={() => connected.update((v) => !v)}>
          Toggle transports
        </button>
        <Show when={connected()}>
          <Transports />
        </Show>
      </section>
      <section>
        <h2>Controlled models</h2>
        <label>
          Text <textarea id="editor-text" model:value={text} />
        </label>
        <label>
          Severity{" "}
          <select id="severity" model:value={severity}>
            <option value="normal">Normal</option>
            <option value="critical">Critical</option>
          </select>
        </label>
        <pre id="editor-output">
          {severity()}:{text()}
        </pre>
      </section>
      <section>
        <h2>Progressive server action</h2>
        <form method="post" action="?/add">
          <label>
            Title <input name="title" required />
          </label>
          <button>Save on server</button>
        </form>
      </section>
      <section>
        <h2>Nested keyed state</h2>
        <label>
          Filter <input id="filter" model:value={filter} />
        </label>
        <button id="reverse" onClick={() => rows.update((r) => [...r].reverse())}>
          Reverse rows
        </button>
        <Show when={visible().length === 0}>
          <p id="empty">No incidents</p>
        </Show>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Draft</th>
              <th>Severity</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody id="incidents">
            <For each={visible()} by={(r) => r.id}>
              {(r) => <IncidentRow incident={r()} />}
            </For>
          </tbody>
        </table>
      </section>
    </main>
  );
}
