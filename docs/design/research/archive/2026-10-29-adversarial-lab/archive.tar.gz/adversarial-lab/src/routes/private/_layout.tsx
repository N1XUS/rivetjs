import { guard, deny, type LayoutProps, type RequestEvent } from "@rivetjs/router";
export const auth = guard(({ cookies }: RequestEvent) => {
  if (cookies.get("lab-session") !== "allowed") throw deny(403, "Login required");
});
export default function PrivateLayout(props: LayoutProps) {
  return (
    <main>
      <h1>Private area</h1>
      {props.children}
    </main>
  );
}
