import { onGet } from "@rivetjs/router";
import { backend } from "../../backend.server.ts";
export const GET = onGet(() => Response.json(backend.stats));
