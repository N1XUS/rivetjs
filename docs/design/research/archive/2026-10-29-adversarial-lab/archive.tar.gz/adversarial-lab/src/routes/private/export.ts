import { onGet } from "@rivetjs/router";
// Deliberately relies on the enclosing layout's guard, exactly like /private.
export const GET = onGet(() => Response.json({ secret: "synthetic-payroll-42000" }));
