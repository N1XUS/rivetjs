import { onGet, onPut, type RequestEvent } from "@rivetjs/router";
import { answer, userOf } from "../../../sites/http.server.ts";
import { draftFor, saveDraft } from "../../../sites/service.server.ts";
export const GET = onGet((e: RequestEvent) => answer(() => draftFor(userOf(e))));
export const PUT = onPut((e: RequestEvent) => answer(async () => saveDraft(userOf(e), await e.request.json())));
