import { load, type PageProps } from "@rivetjs/router";
export const loader = load(() => ({ secret: "synthetic-payroll-42000" }));
export default function Private({ data }: PageProps<typeof loader>) {
  return <p>{data.secret}</p>;
}
