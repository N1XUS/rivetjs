import { onGet, type RequestEvent } from "@rivetjs/router";
import { answer, userOf } from "../../../../sites/http.server.ts";
import { orderFor, Fault } from "../../../../sites/service.server.ts";
export const GET = onGet((e: RequestEvent) =>
  answer(() => {
    const order = orderFor(userOf(e), e.params.id);
    if (!order) throw new Fault(404, "Order not found");
    return order;
  }),
);
