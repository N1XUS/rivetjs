import { onGet } from "@rivetjs/router";
export const GET = onGet(() => Response.json({ secret: "synthetic-payroll-42000" }));
export default function Report() {
  return <p>Private report</p>;
}
