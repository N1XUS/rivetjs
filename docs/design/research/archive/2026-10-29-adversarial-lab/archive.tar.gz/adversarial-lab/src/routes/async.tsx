import { signal } from "@rivetjs/reactivity";
import { Async, resource, Suspense } from "@rivetjs/runtime/dom";
export default function AsyncProbe() {
  const page = signal(1);
  const value = resource(
    () => page(),
    async (key) => {
      await new Promise((r) => setTimeout(r, 10));
      return key;
    },
  );
  return (
    <main>
      <h1>Reactive async after SSR</h1>
      <button id="async-next" onClick={() => page.update((n) => n + 1)}>
        Next
      </button>
      <output id="async-source">{page()}</output>
      <h2>Async load reads source</h2>
      <Async
        load={async () => {
          const key = page();
          await new Promise((r) => setTimeout(r, 10));
          return key;
        }}
        fallback={() => <p>Loading</p>}
      >
        {(n) => <output id="async-result">{n}</output>}
      </Async>
      <h2>Resource reads source</h2>
      <Suspense fallback={() => <p>Loading resource</p>}>
        <output id="resource-result">{value()}</output>
      </Suspense>
    </main>
  );
}
