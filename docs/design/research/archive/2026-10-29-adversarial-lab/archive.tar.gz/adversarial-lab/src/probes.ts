import { read, write, type Store } from "@rivetjs/reactivity/store";
type ArrayStore = Store<{ items: { n: number }[] }>;
// The runtime accepts these paths but StorePath's array type omits length.
// These probes explicitly cross the public type boundary: classify separately
// from the fully typed produce() regression in tests/state.mjs.
export function trackedArrayLength(store: ArrayStore): number {
  return (read as (s: ArrayStore, p: string) => number)(store, "items.length");
}
export function truncateArray(store: ArrayStore): void {
  (write as (s: ArrayStore, p: string, n: number) => void)(store, "items.length", 1);
}
