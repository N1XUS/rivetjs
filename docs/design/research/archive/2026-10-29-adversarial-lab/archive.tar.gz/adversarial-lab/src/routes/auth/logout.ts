import { onPost, redirect, type RequestEvent } from "@rivetjs/router";
import { logout } from "../../sites/http.server.ts";
export const POST = onPost((e: RequestEvent) => {
  logout(e);
  throw redirect("/sign-in", 303);
});
