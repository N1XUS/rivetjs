import { spawn, execFileSync } from "node:child_process";
import { mkdir, open, readFile, writeFile, symlink, lstat, rm, readdir } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import os from "node:os";

const lab = dirname(fileURLToPath(import.meta.url)),
  root = dirname(lab),
  nextDir = join(lab, "controls/next");
const port = Number(process.env.LAB_PORT ?? 4490),
  nextPort = Number(process.env.NEXT_PORT ?? 4491);
const env = {
  ...process.env,
  LAB_URL: `http://127.0.0.1:${port}`,
  NEXT_URL: `http://127.0.0.1:${nextPort}`,
  NEXT_TELEMETRY_DISABLED: "1",
  LAB_DB: join(lab, ".artifacts", `sites-audit-${process.pid}.sqlite`),
};
const children = [],
  steps = [];
await mkdir(join(lab, "results"), { recursive: true });
const req = createRequire(import.meta.url);
const nextManifest = req.resolve("next/package.json", { paths: [nextDir, join(root, "apps/bridge-demo/next")] });
await mkdir(join(nextDir, "node_modules"), { recursive: true });
try {
  await lstat(join(nextDir, "node_modules/next"));
} catch {
  await symlink(dirname(nextManifest), join(nextDir, "node_modules/next"), "dir");
}
const nextBin = join(dirname(nextManifest), "dist/bin/next");

async function start(label, command, args, cwd, extraEnv = {}) {
  const log = await open(join(lab, "results", label + ".log"), "w");
  const child = spawn(command, args, { cwd, env: { ...env, ...extraEnv }, stdio: ["ignore", log.fd, log.fd] });
  children.push(child);
  child.once("close", () => log.close());
  return child;
}
async function command(label, bin, args, cwd = lab) {
  console.log(`Running ${label}`);
  const child = await start(label, bin, args, cwd);
  const code = await new Promise((ok, fail) => {
    child.once("error", fail);
    child.once("close", ok);
  });
  steps.push({ label, code });
  console.log(`${label}: exit ${code}`);
  return code;
}
async function testRun(test, label = test) {
  const resultFile = join(lab, "results", test + ".json");
  await rm(resultFile, { force: true });
  const code = await command(label, process.execPath, [...(test === "state" || test === "controls" ? ["--conditions=browser"] : []), `tests/${test}.mjs`]);
  let records;
  try {
    records = JSON.parse(await readFile(resultFile, "utf8"));
  } catch {
    throw Error(`${label}: subprocess failed to produce fresh JSON (exit ${code})`);
  }
  if (!Array.isArray(records) || !records.length || records.some((r) => typeof r.pass !== "boolean")) throw Error(`${label}: invalid result schema`);
  const expectedCode = records.some((r) => !r.pass) ? 1 : 0;
  if (code !== expectedCode) throw Error(`${label}: process exit ${code}, result assertions imply ${expectedCode}`);
  return { code, results: records };
}
async function ready(url, child) {
  for (let i = 0; i < 100; i++) {
    if (child.exitCode !== null) throw Error(`Server exited ${child.exitCode}; see server log`);
    try {
      const r = await fetch(url + "/identity?user=health");
      await r.body?.cancel();
      return;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  throw Error(`Server did not listen at ${url}`);
}
const sha = execFileSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" }).trim();
const dirty = execFileSync("git", ["diff", "--name-only"], { cwd: root, encoding: "utf8" }).trim().split("\n").filter(Boolean);
const frameworkFiles = execFileSync("git", ["ls-files", "libs"], { cwd: root, encoding: "utf8" }).trim().split("\n");
const hash = createHash("sha256");
for (const path of frameworkFiles) {
  hash.update(path + "\0");
  hash.update(await readFile(join(root, path)));
}
const versions = {};
for (const [name, path] of Object.entries({
  rivet: "libs/runtime/package.json",
  react: "node_modules/react/package.json",
  solidStable: "apps/bench-stable/node_modules/solid-js/package.json",
  vite: "node_modules/vite/package.json",
  playwright: "node_modules/playwright/package.json",
  ws: "node_modules/ws/package.json",
}))
  versions[name] = JSON.parse(await readFile(join(root, path), "utf8")).version;
versions.next = JSON.parse(await readFile(nextManifest, "utf8")).version;
const metadata = {
  recordedAt: new Date().toISOString(),
  node: process.version,
  platform: process.platform,
  arch: process.arch,
  os: os.release(),
  cpu: os.cpus()[0]?.model,
  cpuCount: os.cpus().length,
  loadAverage: os.loadavg(),
  head: sha,
  trackedDirtyPaths: dirty,
  frameworkTrackedFilesSha256: hash.digest("hex"),
  versions,
  URLs: { rivet: env.LAB_URL, next: env.NEXT_URL },
  note: "Workspace snapshot includes pre-existing uncommitted changes. Not a published-release certification or a performance benchmark.",
};
const criticalSources = ["libs/reactivity/store.ts", "libs/router/build/codegen.ts", "libs/runtime/dom-async.ts", "libs/router/server/handler.ts"];
async function sourceHashes() {
  const hashes = {};
  for (const path of criticalSources)
    hashes[path] = createHash("sha256")
      .update(await readFile(join(root, path)))
      .digest("hex");
  return hashes;
}
metadata.criticalSourceHashesBefore = await sourceHashes();
async function fixtureHash() {
  const hash = createHash("sha256");
  for (const dir of ["src", "tests", "controls/next/app"]) {
    const files = (await readdir(join(lab, dir), { recursive: true })).filter((p) => /\.(tsx?|mjs|css)$/.test(p)).sort();
    for (const p of files) {
      hash.update(dir + "/" + p + "\0");
      hash.update(await readFile(join(lab, dir, p)));
    }
  }
  for (const path of ["serve.js", "run.mjs", "vite.config.ts", "package.json", "controls/next/package.json", "controls/next/next.config.mjs"]) {
    hash.update(path + "\0");
    hash.update(await readFile(join(lab, path)));
  }
  return hash.digest("hex");
}
metadata.fixtureSourcesBefore = await fixtureHash();
await writeFile(join(lab, "results/environment.json"), JSON.stringify(metadata, null, 2));
try {
  for (const task of ["check", "build"]) if (await command(task, "npm", ["run", task])) throw Error(`${task} failed`);
  const nextBuild = await command("next-build", process.execPath, [nextBin, "build", nextDir, "--webpack"], root);
  if (nextBuild) {
    const output = await readFile(join(lab, "results/next-build.log"), "utf8");
    if (!output.includes("SecurityFatalError") || (await command("next-build-retry", process.execPath, [nextBin, "build", nextDir, "--webpack"], root)))
      throw Error("Next build failed");
    metadata.nextBuildSecurityAdvisory =
      "Installed Next 16.4.0 emitted SecurityFatalError advisory. Recorded log retained; one retry succeeded. Local comparison only, no security certification.";
  }
  const rivet = await start("server", process.execPath, ["serve.js"], lab, { PORT: String(port) });
  const next = await start("next-server", process.execPath, [nextBin, "start", "--port", String(nextPort), "--hostname", "127.0.0.1"], nextDir);
  await ready(env.LAB_URL, rivet);
  await ready(env.NEXT_URL, next);
  for (const test of ["business", "security", "journeys", "state", "codegen", "http", "browser", "controls", "stress"]) await testRun(test);
  // Repeat only reduced findings, preserving every round's raw observations.
  const repeats = [];
  for (let round = 1; round <= 3; round++) {
    for (const test of ["state", "codegen"]) {
      const result = await testRun(test, `repeat-${round}-${test}`);
      repeats.push({ round, test, ...result });
    }
  }
  await writeFile(join(lab, "results/repeats.json"), JSON.stringify(repeats, null, 2));
  process.exitCode = steps.some((s) => s.code !== 0) ? 1 : 0;
} catch (e) {
  console.error(e);
  steps.push({ label: "infrastructure", error: e.message });
  process.exitCode = 2;
} finally {
  metadata.criticalSourceHashesAfter = await sourceHashes();
  metadata.fixtureSourcesAfter = await fixtureHash();
  metadata.fixtureSourcesUnchanged = metadata.fixtureSourcesBefore === metadata.fixtureSourcesAfter;
  metadata.criticalSourcesUnchanged = JSON.stringify(metadata.criticalSourceHashesBefore) === JSON.stringify(metadata.criticalSourceHashesAfter);
  metadata.headAfter = execFileSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" }).trim();
  metadata.completedAt = new Date().toISOString();
  await writeFile(join(lab, "results/environment.json"), JSON.stringify(metadata, null, 2));
  for (const c of children) if (c.exitCode === null) c.kill("SIGTERM");
  await Promise.all(
    children
      .filter((c) => c.exitCode === null)
      .map(
        (c) =>
          new Promise((resolve) => {
            const timer = setTimeout(() => {
              c.kill("SIGKILL");
              resolve();
            }, 2000);
            c.once("close", () => {
              clearTimeout(timer);
              resolve();
            });
          }),
      ),
  );
  await writeFile(
    join(lab, "results/run.json"),
    JSON.stringify(
      {
        steps,
        exitCode: process.exitCode ?? 0,
        note: "Exit 1 means a correctness expectation failed. Exit 2 means setup/infrastructure failed. No framework defect is patched or marked expected-pass.",
      },
      null,
      2,
    ),
  );
}
